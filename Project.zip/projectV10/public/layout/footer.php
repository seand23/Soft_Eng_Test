<script src="./js/note.js"></script>
<script src="./js/slider.js"></script>
<script src="./js/nav.js"></script>
<footer class="footer">
    <div class="footer-row">
        <div class="footer-col">
            <h3>About Us</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
        <div class="footer-col">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="store.php">Shop</a></li>
                <li><a href="login-register.php">Login</a></li>
                <li><a href="ship.php">Cart</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h3>Contact Info</h3>
            <p>123 Street Name, City, Country</p>
            <p>Email: info@example.com</p>
            <p>Phone: +1234567890</p>
            <p>&copy;All rights reserved.</p>
        </div>
    </div>
</footer>
</body>

</html>