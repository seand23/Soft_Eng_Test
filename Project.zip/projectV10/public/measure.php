<?php require_once "layout/header.php"?>
<link rel="stylesheet" href="./style/measure.css">
<main>
    <div class="video">
        <h1> Enjoy this video on how to measure yourself</h1>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/KkiQH9msHaU?si=98mlr7MzeMkNrsf7" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
    </div>
<?php require_once "layout/footer.php"?>