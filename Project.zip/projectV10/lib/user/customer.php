<?php
require_once 'user.php';
session_start();
class Customer extends Admin{

}