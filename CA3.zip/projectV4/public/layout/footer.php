<script src="./js/basket.js"></script>
<script src="./js/slider.js"></script>
<footer>
        <p>&copy;All rights reserved.</p>
    </footer>
</body>
</html>