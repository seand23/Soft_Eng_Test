<?php

return array(
    'database_dsn' => 'mysql:dbname=softeng;host=localhost',
    'database_user' => 'root',
    'database_pass' => 'Kvjn2762!'
);