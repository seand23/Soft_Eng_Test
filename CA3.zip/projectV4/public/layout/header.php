<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blanch Suits</title>
    <link rel="stylesheet" href="./style/main.css">
    <link rel="stylesheet" href="./style/nav.css">
    <link rel="stylesheet" href="./style/slider.css">

    
    
</head>
<body>
        
<nav>
    <div class="search-bar">
    <input type="text" placeholder="Search...">
    <button type="searchB">Search</button>
    </div>
    <a href="index.php">Home</a>
    <a href="store.php">Store</a>
    <a href="#">Contact</a>
    <div class="login">
    <button><a href="login.php">LOGIN</a></button>
    <button><a href="signup.php">REGISTER</a></button>
    <button><a href="ship.php">Cart</a></button>
    </div>
</nav>
