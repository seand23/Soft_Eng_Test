function closeNote() {
    var element = document.querySelector('.note');
    element.parentNode.removeChild(element);
}
